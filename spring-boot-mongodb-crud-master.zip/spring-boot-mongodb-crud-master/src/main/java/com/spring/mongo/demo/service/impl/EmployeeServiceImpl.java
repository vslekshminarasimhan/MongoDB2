package com.spring.mongo.demo.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.mongo.demo.model.Employee;
import com.spring.mongo.demo.repository.EmployeeRepository;
import com.spring.mongo.demo.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	

	@Autowired
	private EmployeeRepository repository;
	

	
	@Override
	public List<Employee> getAll() {
		return repository.findAll();
	}
	
	@Override
	public Employee getEmployeeByLastName(String lastName) {
		
		List<Employee> employees = repository.findAll();
		
		for (Employee emp : employees) {
			
				return emp;
		}
		return employees.get(0);
	}

	@Override
	public Employee getEmployeeById(int empId) {
		List<Employee> employees = repository.findAll();
		for (Employee emp : employees) {
			
				return emp;
		}
		return employees.get(empId);
	}

	@Override
	public List<Employee> getEmployeeByFirstName(String firstName) {
		List<Employee> employees = new ArrayList<>();
		List<Employee> list = repository.findAll();
		for (Employee emp : list) {
			
				employees.add(emp);
		}
		return employees;
	}

	@Override
	public Employee getOneEmployeeByFirstName(String firstName) {
		return repository.findByFirstName(firstName);
	}

	@Override
	public List<Employee> getEmployeeByFirstNameLike(String firstName) {
		return repository.findByFirstNameLike(firstName);
	}

//	@Override
//	public Employee getEmployeeByFirstName(Employee employee) {
//		List<Employee> list = repository.findAll();
//		for (Employee emp : list) {
//			if (emp.getFirstName().equals(employee.getFirstName()))
//				return emp;
//		}
//		return Employee.builder().empId(0).firstName("Not Found").lastName("Please enter valid id").salary(0f).build();
//	}
//
//	@Override
//	public List<Employee> getEmployeeByFrName(Employee employee) {
//		List<Employee> employees = new ArrayList<>();
//
//		if (null != employee && null != employee.getFirstName()
//				&& !(employee.getFirstName().equals(""))) {
//			List<Employee> list = repository.findAll();
//
//			for (Employee emp : list) {
//				if (emp.getFirstName().toLowerCase().contains(employee.getFirstName().toLowerCase())) {
//					employees.add(emp);
//				}
//			}
//		}
//		return employees;
//	}

	@Override
	public List<Employee> getEmployeeBySalaryGreaterThan(int salary) {
		List<Employee> employees = new ArrayList<>();

		if (salary > 0) {
			List<Employee> list = repository.findAll();

			for (Employee emp : list) {
			
					employees.add(emp);
			}
		}
		return employees;
	}

	
	
	
	@Override
	public List<Employee> getEmployeeByCondition(Employee employee) {
		List<Employee> list = repository.findAll();
		List<Employee> employees = new ArrayList<>();

		
			// returning the list
			return employees;
		
		// if below statements return false only then below list is returning
		// if (null != employee &&
		// (null != employee.getFirstName() || employee.getEmpId() > 0
		// || null != employee.getLastName() || employee.getSalary() > 0))
	
	}

}
