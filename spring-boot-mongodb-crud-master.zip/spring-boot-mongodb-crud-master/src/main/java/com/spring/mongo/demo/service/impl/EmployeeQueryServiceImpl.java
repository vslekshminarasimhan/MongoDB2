package com.spring.mongo.demo.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.mongo.demo.model.Employee;
import com.spring.mongo.demo.repository.EmployeeQueryDao;
import com.spring.mongo.demo.service.EmployeeQueryService;
import org.springframework.util.StringUtils;

@Service
public class EmployeeQueryServiceImpl implements EmployeeQueryService {

	@Autowired
	private EmployeeQueryDao employeeQueryDao;

	@Override
	public List<Employee> getAll() {
		System.out.println("Inside Employee Query Service Impl");
		return employeeQueryDao.getAll();
	}

	@Override
	public List<Employee> getEmployeeByFirstName(String firstName) {

		if (!StringUtils.isEmpty(firstName)) {
			return employeeQueryDao.getEmployeeByFirstName(firstName);
		}

		return null;
	}


	@Override
	public Employee getOneEmployeeByFirstName(String firstName) {

		if (!StringUtils.isEmpty(firstName)) {
			return employeeQueryDao.getSingleEmployeeByFirstName(firstName);
		}

		return null;
	}
	@Override
	public List<Employee> getEmployeeByFirstNameLike(String firstName) {

		if (!StringUtils.isEmpty(firstName)) {
			return employeeQueryDao.getEmployeeByFirstNameLike(firstName);
		}

		return null;
	}


	@Override
	public Employee getSingleEmployeeByLastName(String lastName) {

		if (!StringUtils.isEmpty(lastName)) {
			return employeeQueryDao.getSingleEmployeeByLastName(lastName);
		}
		Employee emp = new Employee();
		return emp; //Employee.empId(0).firstName("Not Found").lastName("Please enter valid last name").salary(0f).build();
	}

	@Override
	public List<Employee> getEmployeeBySalaryGreaterThan(int salary) {

		if (salary > 0) {
			return employeeQueryDao.getEmployeeBySalaryGreaterThan(salary);
		}
		return Collections.emptyList();
	}

	@Override
	public List<Employee> getEmployeeByCondition(Employee employee) {
		List<Employee> list = employeeQueryDao.getAll();
		List<Employee> employees = new ArrayList<>();

	
			return employees;
		
	}

}
